/**
 * 
 */

/**
 * @author moise
 *
 */
public abstract class List<E> implements IList<E> {

}
